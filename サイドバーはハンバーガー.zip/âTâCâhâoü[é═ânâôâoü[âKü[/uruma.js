"use strict";

document.getElementById("h22").addEventListener("click", () => {
  document.getElementById("h22").style.fontSize = "10rem";
});
